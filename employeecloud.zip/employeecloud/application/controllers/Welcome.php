<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('includes/login_reg_header');
		$this->load->view('login');
		$this->load->view('includes/login_reg_footer');
	}

	public function register()
	{	
		$data["colleges"] = $this->Ajax_Model->getColleges();
		$this->load->view('includes/login_reg_header');
		$this->load->view('register',$data);
		$this->load->view('includes/login_reg_footer');
	}

	public function register_company()
	{	
		$this->load->view('includes/login_reg_header');
		$this->load->view('register_company');
		$this->load->view('includes/login_reg_footer');
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect(base_url());
	}
}
