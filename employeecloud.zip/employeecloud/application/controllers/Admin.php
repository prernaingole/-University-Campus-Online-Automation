<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	function __construct() {
		parent::__construct();
		if ($this->session->role != "admin") {
			redirect(base_url());
		}
	}

	public function index()
	{
		$data["page_title"] = "Dashboard";
		$this->load->view('includes/header_admin',$data);
		$this->load->view('includes/sidebar_admin',$data);
		$this->load->view('admin/admin_dashboard');
		$this->load->view('includes/footer_admin');
	}

	public function companies()
	{
		$data["page_title"] = "Companies";
		$data["companies"] = $this->Ajax_Model->getCompanies();
		$this->load->view('includes/header_admin',$data);
		$this->load->view('includes/sidebar_admin',$data);
		$this->load->view('admin/admin_companies',$data);
		$this->load->view('includes/footer_admin');
	}
	
	public function universities()
	{
		$data["page_title"] = "Universities";
		$this->load->view('includes/header_admin',$data);
		$this->load->view('includes/sidebar_admin',$data);
		$this->load->view('admin/admin_universities');
		$this->load->view('includes/footer_admin');
	}

	public function notifications()
	{
		$data["page_title"] = "Notifications";
		$data["notifications"] = $this->Ajax_Model->getNotifications();
		$this->load->view('includes/header_admin',$data);
		$this->load->view('includes/sidebar_admin',$data);
		$this->load->view('admin/admin_notifications',$data);
		$this->load->view('includes/footer_admin');
	}

	public function students()
	{
		$data["page_title"] = "Students";
		$this->load->view('includes/header_admin',$data);
		$this->load->view('includes/sidebar_admin',$data);
		$this->load->view('admin/admin_students');
		$this->load->view('includes/footer_admin');
	}

}
