<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Ajax extends CI_Controller {
	public function registerStudent()
	{
		$student = array(
			"name" => $this->input->post('name'),
			"username" => $this->input->post('username'),
			"password" => $this->input->post('password'),
			"branch" => $this->input->post('branch'),
			"year" => $this->input->post('year'),
			"uid" => $this->input->post('uid'),
			"gender" => $this->input->post('gender'),
			"contact_no" => $this->input->post('contact_no'),
			"email" => $this->input->post('email')
		);
		$this->send_mail('Student');
		$this->Ajax_Model->insertData($student,"students");
		echo json_encode(array("status" => "1"));
	}

	public function updateEducationalInfo()
	{
		$student = array(
			"ssc_institute" => $this->input->post('ssc_institute'),
			"ssc_yop" => $this->input->post('ssc_yop'),
			"ssc_total" => $this->input->post('ssc_total'),
			"ssc_marks" => $this->input->post('ssc_marks'),
			"ssc_percentage" => $this->input->post('ssc_percentage'),
			"hsc_institute" => $this->input->post('hsc_institute'),
			"hsc_branch" => $this->input->post('hsc_branch'),
			"hsc_yop" => $this->input->post('hsc_yop'),
			"hsc_total" => $this->input->post('hsc_total'),
			"hsc_marks" => $this->input->post('hsc_marks'),
			"hsc_percentage" => $this->input->post('hsc_percentage'),
			"diploma_institute" => $this->input->post('diploma_institute'),
			"diploma_branch" => $this->input->post('diploma_branch'),
			"diploma_yop" => $this->input->post('diploma_yop'),
			"diploma_total" => $this->input->post('diploma_total'),
			"diploma_marks" => $this->input->post('diploma_marks'),
			"diploma_percentage" => $this->input->post('diploma_percentage'),
			"be_institute" => $this->input->post('be_institute'),
			"be_branch" => $this->input->post('be_branch'),
			"be_sem1_marks" => $this->input->post('be_sem1_marks'),
			"be_sem1_percentage" => $this->input->post('be_sem1_percentage'),
			"be_sem1_sgpa" => $this->input->post('be_sem1_sgpa'),
			"be_sem2_marks" => $this->input->post('be_sem2_marks'),
			"be_sem2_percentage" => $this->input->post('be_sem2_percentage'),
			"be_sem2_sgpa" => $this->input->post('be_sem2_sgpa'),
			"be_sem3_marks" => $this->input->post('be_sem3_marks'),
			"be_sem3_percentage" => $this->input->post('be_sem3_percentage'),
			"be_sem3_sgpa" => $this->input->post('be_sem3_sgpa'),
			"be_sem4_marks" => $this->input->post('be_sem4_marks'),
			"be_sem4_percentage" => $this->input->post('be_sem4_percentage'),
			"be_sem4_sgpa" => $this->input->post('be_sem4_sgpa'),
			"be_sem5_marks" => $this->input->post('be_sem5_marks'),
			"be_sem5_percentage" => $this->input->post('be_sem5_percentage'),
			"be_sem5_sgpa" => $this->input->post('be_sem5_sgpa'),
			"be_sem6_marks" => $this->input->post('be_sem6_marks'),
			"be_sem6_percentage" => $this->input->post('be_sem6_percentage'),
			"be_sem6_sgpa" => $this->input->post('be_sem6_sgpa'),
			"be_sem7_marks" => $this->input->post('be_sem7_marks'),
			"be_sem7_percentage" => $this->input->post('be_sem7_percentage'),
			"be_sem7_sgpa" => $this->input->post('be_sem7_sgpa'),
			"be_sem8_marks" => $this->input->post('be_sem8_marks'),
			"be_sem8_percentage" => $this->input->post('be_sem8_percentage'),
			"be_sem8_sgpa" => $this->input->post('be_sem8_sgpa'),
		);
		$this->db->where("id",$this->session->id)->update("students",$student);
		echo json_encode(array("status" => "1"));
	}

	public function addCertificate() {
		if(isset($_FILES['image'])){
			$errors= array();
			$file_name = $_FILES['image']['name'];
			$file_size =$_FILES['image']['size'];
			$file_tmp =$_FILES['image']['tmp_name'];
			$file_type=$_FILES['image']['type'];
			$end = explode('.',$_FILES['image']['name']);
			$file_ext=strtolower(end($end));
			
			$extensions= array("pdf","jpg");
			
			if(in_array($file_ext,$extensions)=== false){
			   $errors[]="extension not allowed, please choose a JPEG or PNG file.";
			}
			
			$path = realpath(APPPATH . '../uploads');
			if(empty($errors)==true){
			   move_uploaded_file($file_tmp,"$path/".$file_name);
			   $this->db->insert("student_certificates",array(
				   "student_id" => $this->session->id,
				   "certificate_name" => $file_name,
				   "certificate_details" => base_url() . "uploads/$file_name"
			   ));
			   echo json_encode(array("status" => "Success"));
			}else{
			   print_r($errors);
			}
		 }
	}
	public function addAchievement()
	{
		$achievement = array(
			"student_id" => $this->session->id,
			"achievement_name" => $this->input->post('title'),
			"givenby" => $this->input->post('givenby'),
			"achievement_details" => $this->input->post('details')
		);
		$this->Ajax_Model->insertData($achievement,"student_achievements");
		echo json_encode(array("status" => "1"));
	}
	public function addCompany()
	{
		$company = array(
			"name" => $this->input->post('company_name'),
			"username" => $this->input->post('company_username'),
			"password" => $this->input->post('company_password'),
			"company_address" => $this->input->post('company_address'),
			"company_contact" => $this->input->post('company_contact')
			);
		$this->send_mail('Company');
		$this->Ajax_Model->insertData($company,"companies");
		echo json_encode(array("status" => "1"));
	}

	public function send_mail($userType) { 
		$from_email = "admin@employeecloud.tk"; 
		$to_email = $this->input->post('email'); 
  
		//Load email library 
		$this->load->library('email'); 
  
		$this->email->from($from_email, 'EmployeeCloud Admin'); 
		$this->email->to($to_email);
		$this->email->subject('New Registration'); 
		$this->email->message('A new ' . $userType . ' has been registered.'); 
  
		//Send mail 
		$this->email->send(); 
	 } 


	public function updateStudent()
	{
		$this->Ajax_Model->updateStudent();
		echo json_encode(array("status" => "1"));
	}
	public function login()
	{
		$userPrev = array(
			"username" => $this->input->post('username'),
			"password" => $this->input->post('password'),
			"role" => $this->input->post('role')
		);
		$user = $this->Ajax_Model->loginUser($userPrev);
		if ($user->id != "0") {
			$this->session->set_userdata("id",$user->id);
			$this->session->set_userdata("role",$userPrev["role"]);
			$this->session->set_userdata("name",$user->name);
			echo json_encode(array("status" => "1"));
		}
		else {
			echo json_encode(array("status" => "0"));
		}
	}
}
