<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Students extends CI_Controller {

	function __construct() {
		parent::__construct();
		if ($this->session->role != "students") {
			redirect(base_url());
		}
		else {
			$this->student = $this->Ajax_Model->getStudentInfo($this->session->id);
		}
	}

	public function index()
	{
		$data["page_title"] = "Dashboard";
		$data["student"] = $this->student;
		$this->load->view('includes/header_students',$data);
		$this->load->view('includes/sidebar_students',$data);
		$this->load->view('students/student_dashboard',$data);
		$this->load->view('includes/footer_students');
	}

	public function allcompanies()
	{
		$data["page_title"] = "All Companies";
		$data["student"] = $this->student;
		$data["companies"] = $this->Ajax_Model->getCompanies();
		$this->load->view('includes/header_students',$data);
		$this->load->view('includes/sidebar_students',$data);
		$this->load->view('students/student_all_companies',$data);
		$this->load->view('includes/footer_students');
	}

	public function notifications()
	{
		$data["page_title"] = "Notifications";
		$data["student"] = $this->student;
		$data["notifications"] = $this->Ajax_Model->getNotifications();
		$this->load->view('includes/header_students',$data);
		$this->load->view('includes/sidebar_students',$data);
		$this->load->view('students/student_notifications');
		$this->load->view('includes/footer_students');
	}

	public function basicdetails()
	{
		$data["page_title"] = "Basic Details";
		$data["student"] = $this->student;
		$data["colleges"] = $this->Ajax_Model->getColleges();
		$this->load->view('includes/header_students',$data);
		$this->load->view('includes/sidebar_students',$data);
		$this->load->view('students/student_basic_details');
		$this->load->view('includes/footer_students');
	}
	
	public function educationaldetails()
	{
		$data["page_title"] = "Educational Details";
		$data["student"] = $this->student;
		$data["colleges"] = $this->Ajax_Model->getColleges();
		$this->load->view('includes/header_students',$data);
		$this->load->view('includes/sidebar_students',$data);
		$this->load->view('students/student_educational_details',$data);
		$this->load->view('includes/footer_students');
	}

	public function achievements()
	{
		$data["page_title"] = "Achievements";
		$data["student"] = $this->student;
		$data["achievements"] = $this->Ajax_Model->getAchievements($this->session->id);
		$this->load->view('includes/header_students',$data);
		$this->load->view('includes/sidebar_students',$data);
		$this->load->view('students/student_achievements');
		$this->load->view('includes/footer_students');
	}

	public function certificates()
	{
		$data["page_title"] = "Certificates";
		$data["student"] = $this->student;
		$data["certificates"] = $this->db->where("student_id",$this->session->id)->get("student_certificates")->result();
		$this->load->view('includes/header_students',$data);
		$this->load->view('includes/sidebar_students',$data);
		$this->load->view('students/student_certificates');
		$this->load->view('includes/footer_students');
	}



}
