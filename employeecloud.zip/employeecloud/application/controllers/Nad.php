<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nad extends CI_Controller {

	function __construct() {
		parent::__construct();
		if (!$this->session->role == "nad") {
			redirect(base_url());
		}
	}

	public function index()
	{
		$data["page_title"] = "Dashboard";
		$this->load->view('includes/header_nad',$data);
		$this->load->view('includes/sidebar_nad',$data);
		$this->load->view('nad/nad_dashboard');
		$this->load->view('includes/footer_nad');
	}

	public function notifications()
	{
		$data["page_title"] = "Notifications";
		$this->load->view('includes/header_nad',$data);
		$this->load->view('includes/sidebar_nad',$data);
		$this->load->view('nad/nad_notifications');
		$this->load->view('includes/footer_nad');
	}

	public function students()
	{
		$data["page_title"] = "Students";
		$data["students"] = $this->db->get('students')->result();
		$this->load->view('includes/header_nad',$data);
		$this->load->view('includes/sidebar_nad',$data);
		$this->load->view('nad/nad_students',$data);
		$this->load->view('includes/footer_nad');
	}

	public function profile()
	{
		$data["page_title"] = "Profile";
		$this->load->view('includes/header_nad',$data);
		$this->load->view('includes/sidebar_nad',$data);
		$this->load->view('nad/nad_profile');
		$this->load->view('includes/footer_nad');
	}

}
