<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Companies extends CI_Controller {

	function __construct() {
		parent::__construct();
		if (!$this->session->role == "companies") {
			redirect(base_url());
		}
	}

	public function notifications()
	{
		$data["page_title"] = "Notifications";
		$this->load->view('includes/header_companies',$data);
		$this->load->view('includes/sidebar_companies',$data);
		$this->load->view('companies/companies_notifications');
		$this->load->view('includes/footer_companies');
	}

	public function index()
	{
		$data["page_title"] = "Students";
		$data["students"] = $this->db->get('students')->result();
		$this->load->view('includes/header_companies',$data);
		$this->load->view('includes/sidebar_companies',$data);
		$this->load->view('companies/companies_students',$data);
		$this->load->view('includes/footer_companies');
	}

	public function profile()
	{
		$data["page_title"] = "Profile";
		$this->load->view('includes/header_companies',$data);
		$this->load->view('includes/sidebar_companies',$data);
		$this->load->view('companies/companies_profile');
		$this->load->view('includes/footer_companies');
	}

}
