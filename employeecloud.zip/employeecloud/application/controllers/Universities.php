<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Universities extends CI_Controller {

	function __construct() {
		parent::__construct();
		if (!$this->session->role == "universities") {
			redirect(base_url());
		}
	}

	public function index()
	{
		$data["page_title"] = "Dashboard";
		$data["students"] = $this->db->get('students')->result();
		$this->load->view('includes/header_universities',$data);
		$this->load->view('includes/sidebar_universities',$data);
		$this->load->view('universities/universities_students',$data);
		$this->load->view('includes/footer_universities');
	}

}
