<div id="login-page" class="row">
  <div class="col s12 z-depth-4 card-panel">
    <form class="login-form">
      <div class="row">
        <div class="input-field col s12 center">
          <img src="<?php echo base_url(); ?>assets/images/login-logo.jpg" alt=""
            class="responsive-img valign profile-image-login">
          <p class="center login-form-text">Please Login</p>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="username" type="text">
          <label for="username" class="center-align">Username</label>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="mdi-action-lock-outline prefix"></i>
          <input id="password" type="password">
          <label for="password">Password</label>
        </div>
        <div class="input-field col s12">
          <select id="loginAs">
            <option value="" disabled selected>Login As</option>
            <option value="1">Student</option>
            <option value="2">Company</option>
            <option value="3">University</option>
            <option value="4">Admin</option>
            <option value="5">NAD</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <a href="" id="btnLogin" class="btn waves-effect waves-light col s12">Login</a>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s6 m6 l6">
          <p class="margin medium-small"><a href="<?php echo base_url(); ?>register">Register Now!</a></p>
        </div>
        <div class="input-field col s6 m6 l6">
          <p class="margin medium-small"><a href="<?php echo base_url(); ?>register_company">Register As Company</a></p>
        </div>
      </div>
    </form>
  </div>
</div>