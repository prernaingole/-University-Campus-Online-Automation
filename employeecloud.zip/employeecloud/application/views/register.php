<div id="login-page" class="row">
  <div class="col s12 z-depth-4 card-panel">
    <form class="login-form">
      <div class="row">
        <div class="input-field col s12 center">
          <h4>Register</h4>
          <p class="center">Create your student profile today !</p>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="name" type="text">
          <label for="name" class="center-align">Full Name</label>
        </div>
        <!-- <div class="input-field col s12">
          <select id="branch">
            <option value="" disabled selected>Select Branch</option>
            <option value="CSE">CSE</option>
            <option value="EXTC">EXTC</option>
            <option value="CIVIL">CIVIL</option>
            <option value="MECH">MECH</option>
          </select>
        </div>
        <div class="input-field col s12">
          <select id="year">
            <option value="" disabled selected>Select Year</option>
            <option value="1">First Year</option>
            <option value="2">Second Year</option>
            <option value="3">Third Year</option>
            <option value="4">Final Year</option>
          </select>
        </div> -->
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="email" type="text">
          <label for="email">E-mail</label>
        </div>
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="contact" type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
          <label for="contact" class="center-align">Contact no.</label>
        </div>
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="username" type="text">
          <label for="username">Username</label>
        </div>
        <div class="input-field col s12">
          <i class="mdi-action-lock-outline prefix"></i>
          <input id="password" type="password">
          <label for="password">Password</label>
        </div>
        <div class="input-field col s12">
          <i class="mdi-action-lock-outline prefix"></i>
          <input id="confirm_password" type="password">
          <label for="confirm_password">Confirm Password</label>
        </div>
        <div class="input-field col s12">
          <p>Please select gender</p>
          <form action="#">
            <p>
              <input checked id="genderMale" value="male" name="gender" type="radio" />
              <label for="genderMale">Male</label>
            </p>
            <p>
              <input id="genderFemale" value="female" name="gender" type="radio" />
              <label for="genderFemale">Female</label>
            </p>
          </form>
        </div>
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="aadhar" type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="12">
          <label for="aadhar">Aadhar UID</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field col s12">
          <a id="btnRegister" class="btn waves-effect waves-light col s12">Register Now</a>
        </div>
        <div class="input-field col s12">
          <p class="margin center medium-small sign-up">Already have an account? <a href="<?php echo base_url(); ?>login">Login</a></p>
        </div>
      </div>
    </form>
  </div>
</div>