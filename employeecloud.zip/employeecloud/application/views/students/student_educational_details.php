<!--start container-->
<div class="container">
  <div class="section">
    <div class="row">
      <div class="col s12">
        <div class="card-panel">
          <h4 class="header3">Educational Details</h4>
          <!-- Inline Form -->
          <div class="row">
            <div class="col s12">
              <div class="row">
                  <h5 class="header2">10th / SSC</h5>
                  <form class="col s12">
                    <div class="row">
                      <div class="input-field col s12 m4 l3">
                        <input id="ssc_institute" value="<?=$student->ssc_institute;?>" type="text" class="validate">
                        <label for="ssc_institute">SSC BOARD</label>
                      </div>
                      <div class="input-field col s12 m4 l3">
                        <input id="ssc_yop" value="<?=$student->ssc_institute;?>" type="text" class="validate">
                        <label for="ssc_yop">Year of Passing</label>
                      </div>
                      <div class="input-field col s12 m2 l2">
                        <input id="ssc_total" value="<?=$student->ssc_total;?>" type="text" class="validate">
                        <label for="ssc_total">Total Marks</label>
                      </div>
                      <div class="input-field col s12 m2 l2">
                        <input id="ssc_marks" value="<?=$student->ssc_marks;?>" type="text" class="validate">
                        <label for="ssc_marks">Marks</label>
                      </div>
                      <div class="input-field col s12 m1 l1">
                        <p id="ssc_percentage"><?=$student->ssc_percentage;?> %</p>
                      </div>
                    </div>
                  </form>
                </div>
                <div class="row">
                    <h5 class="header2">12th / HSC</h5>
                    <form class="col s12">
                      <div class="row">
                        <div class="input-field col s12 m3 l3">
                          <input id="hsc_institute" value="<?=$student->hsc_institute;?>" type="text" class="validate">
                          <label for="hsc_institute">HSC BOARD</label>
                        </div>
                        <div class="input-field col s12 m3 l2">
                          <input id="hsc_branch" value="<?=$student->hsc_branch;?>" type="text" class="validate">
                          <label for="hsc_branch">Branch</label>
                        </div>
                        <div class="input-field col s12 m3 l1">
                          <input id="hsc_yop" value="<?=$student->hsc_yop;?>" type="text" class="validate">
                          <label for="hsc_yop">Year</label>
                        </div>
                        <div class="input-field col s12 m1 l2">
                          <input id="hsc_total" value="<?=$student->hsc_total;?>" type="text" class="validate">
                          <label for="hsc_total">Total Marks</label>
                        </div>
                        <div class="input-field col s12 m1 l2">
                          <input id="hsc_marks" value="<?=$student->hsc_marks;?>" type="text" class="validate">
                          <label for="hsc_marks">Marks</label>
                        </div>
                        <div class="input-field col s12 m1 l1">
                          <p id="hsc_percentage"><?=$student->hsc_percentage;?> %</p>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class="row">
                      <h5 class="header2">Polytechnic / Diploma</h5>
                      <form class="col s12">
                        <div class="row">
                          <div class="input-field col s12 m3 l3">
                            <input id="diploma_institute"  value="<?=$student->diploma_marks;?>" type="text" class="validate">
                            <label for="diploma_institute">Institute</label>
                          </div>
                          <div class="input-field col s12 m3 l2">
                            <input id="diploma_branch"  value="<?=$student->diploma_branch;?>" type="text" class="validate">
                            <label for="diploma_branch">Branch</label>
                          </div>
                          <div class="input-field col s12 m3 l1">
                            <input id="diploma_yop"  value="<?=$student->diploma_yop;?>" type="text" class="validate">
                            <label for="diploma_yop">Year</label>
                          </div>
                          <div class="input-field col s12 m1 l2">
                            <input id="diploma_total"  value="<?=$student->diploma_total;?>" type="text" class="validate">
                            <label for="diploma_total">Total Marks</label>
                          </div>
                          <div class="input-field col s12 m1 l2">
                            <input id="diploma_marks"  value="<?=$student->diploma_marks;?>" type="text" class="validate">
                            <label for="diploma_marks">Marks</label>
                          </div>
                          <div class="input-field col s12 m1 l1">
                            <p id="diploma_percentage"><?=$student->diploma_percentage;?> %</p>
                          </div>
                        </div>
                      </form>
                    </div>

                    <div class="row">
                        <h5 class="header2">B.E. / Engineering</h5>
                        <form class="col s12">
                          <div class="row">
                            <div class="input-field col s12 m6 l4">
                              <input id="be_institute"  value="<?=$student->be_institute;?>" type="text" class="validate">
                              <label for="be_institute">Institute</label>
                            </div>
                            <div class="input-field col s12 m6 l4">
                              <input id="be_branch"  type="text" class="validate">
                              <label for="be_branch">Branch</label>
                            </div>
                          </div>

                            <h4 class="header2">Semester 1</h4>
                          <div class="row">
                            <div class="input-field col s12 m4 l3">
                              <input id="be_marks_1"  value="<?=$student->be_sem1_marks;?>" type="text" class="validate">
                              <label for="be_marks_1">Marks</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_percentage_1"  value="<?=$student->be_sem1_percentage;?>" type="text" class="validate">
                              <label for="be_percentage_1">Percentage</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_sgpa_1"  type="text" value="<?=$student->be_sem1_sgpa;?>" class="validate">
                              <label for="be_sgpa_1">S.G.P.A</label>
                            </div>
                          </div>
                            <h4 class="header2">Semester 2</h4>
                          <div class="row">
                            <div class="input-field col s12 m4 l3">
                              <input id="be_marks_2"  value="<?=$student->be_sem2_marks;?>" type="text" class="validate">
                              <label for="be_marks_2">Marks</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_percentage_2"  value="<?=$student->be_sem2_percentage;?>" type="text" class="validate">
                              <label for="be_percentage_2">Percentage</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_sgpa_2"  type="text" value="<?=$student->be_sem2_sgpa;?>" class="validate">
                              <label for="be_sgpa_2">S.G.P.A</label>
                            </div>
                          </div>
                            
                            <h4 class="header2">Semester 3</h4>
                          <div class="row">
                            <div class="input-field col s12 m4 l3">
                              <input id="be_marks_3"  value="<?=$student->be_sem3_marks;?>" type="text" class="validate">
                              <label for="be_marks_3">Marks</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_percentage_3"  value="<?=$student->be_sem3_percentage;?>" type="text" class="validate">
                              <label for="be_percentage_3">Percentage</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_sgpa_3"  type="text" value="<?=$student->be_sem3_sgpa;?>" class="validate">
                              <label for="be_sgpa_3">S.G.P.A</label>
                            </div>
                          </div>
                            

                            <h4 class="header2">Semester 4</h4>
                          <div class="row">
                            <div class="input-field col s12 m4 l3">
                              <input id="be_marks_4"  value="<?=$student->be_sem4_marks;?>" type="text" class="validate">
                              <label for="be_marks_4">Marks</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_percentage_4"  value="<?=$student->be_sem4_percentage;?>" type="text" class="validate">
                              <label for="be_percentage_4">Percentage</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_sgpa_4"  type="text" value="<?=$student->be_sem4_sgpa;?>" class="validate">
                              <label for="be_sgpa_4">S.G.P.A</label>
                            </div>
                          </div>

                            <h4 class="header2">Semester 5</h4>
                          <div class="row">
                            <div class="input-field col s12 m4 l3">
                              <input id="be_marks_5"  value="<?=$student->be_sem5_marks;?>" type="text" class="validate">
                              <label for="be_marks_5">Marks</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_percentage_5"  value="<?=$student->be_sem5_percentage;?>" type="text" class="validate">
                              <label for="be_percentage_5">Percentage</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_sgpa_5"  type="text" value="<?=$student->be_sem5_sgpa;?>" class="validate">
                              <label for="be_sgpa_5">S.G.P.A</label>
                            </div>
                          </div>

                            <h4 class="header2">Semester 6</h4>
                          <div class="row">
                            <div class="input-field col s12 m4 l3">
                              <input id="be_marks_6"  value="<?=$student->be_sem6_marks;?>" type="text" class="validate">
                              <label for="be_marks_6">Marks</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_percentage_6"  value="<?=$student->be_sem6_percentage;?>" type="text" class="validate">
                              <label for="be_percentage_6">Percentage</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_sgpa_6"  type="text" value="<?=$student->be_sem6_sgpa;?>" class="validate">
                              <label for="be_sgpa_6">S.G.P.A</label>
                            </div>
                          </div>

                            <h4 class="header2">Semester 7</h4>
                          <div class="row">
                            <div class="input-field col s12 m4 l3">
                              <input id="be_marks_7"  value="<?=$student->be_sem7_marks;?>" type="text" class="validate">
                              <label for="be_marks_7">Marks</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_percentage_7"  value="<?=$student->be_sem7_percentage;?>" type="text" class="validate">
                              <label for="be_percentage_7">Percentage</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_sgpa_7"  type="text" value="<?=$student->be_sem7_sgpa;?>" class="validate">
                              <label for="be_sgpa_7">S.G.P.A</label>
                            </div>
                          </div>
                            
                          <h4 class="header2">Semester 8</h4>
                          <div class="row">
                            <div class="input-field col s12 m4 l3">
                              <input id="be_marks_8"  value="<?=$student->be_sem8_marks;?>" type="text" class="validate">
                              <label for="be_marks_8">Marks</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_percentage_8"  value="<?=$student->be_sem8_percentage;?>" type="text" class="validate">
                              <label for="be_percentage_8">Percentage</label>
                            </div>
                            <div class="input-field col s12 m4 l3">
                              <input id="be_sgpa_8"  type="text" value="<?=$student->be_sem8_sgpa;?>" class="validate">
                              <label for="be_sgpa_8">S.G.P.A</label>
                            </div>
                          </div>

                        </form>
                      </div>
                      <br>  
                      <div class="row">
                        <div class="col s3 offset-l9">
                          <a id="btnUpdateEduInfo" href class="btn btn-block">Update Information</a>
                        </div>
                      </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <br>
  <!-- Floating Action Button -->
  <!--end container-->