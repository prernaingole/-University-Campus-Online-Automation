<!--start container-->
<div class="container">
  <div class="section">





    <div class="row">
      <?php if ($companies) {
    foreach ($companies as $company) {
        ?>
         <div class="col s12 m4 l3">
                  <div class="card">
                      <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo base_url(); ?>assets/images/company.png" alt="office">
                      </div>
                      <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4"><?=$company->name;?><i class="mdi-navigation-more-vert right"></i></span>
                        <p><a href="tel:<?=$company->company_contact;?>">Call <?=$company->company_contact;?></a>
                        </p>
                      </div>
                      <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">Address of <?=$company->name;?><i class="mdi-navigation-close right"></i></span>
                        <p><?=$company->company_address;?></p>
                      </div>
                    </div>
                </div>
      <?php }
} else {?>
      <p class="caption">No Companies Found</p>
      <div class="divider"></div>
      <?php }
?>
 </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  </div>
  <!-- Floating Action Button -->
        <!--end container-->
