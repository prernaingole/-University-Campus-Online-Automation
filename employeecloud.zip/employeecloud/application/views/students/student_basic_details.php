 <!--start container-->
 <div class="container">
          <div class="section">
          <div class="row">
            <div class="col s12 m12 l12">
              <div class="card-panel">
                <h4 class="header2">Basic Details</h4>
                <div class="row">
                  <form class="col s12">
                    <div class="row">
                      <div class="input-field col s4">
                        <input id="full_name" type="text" value="<?=$student->name;?>">
                        <label for="full_name">Full Name</label>
                      </div>
                    
                      <div class="input-field col s4">
                        <input id="parents_no" type="text" value="<?=$student->contact_no;?>">
                        <label for="parents_no">Parents Mobile Number</label>
                      </div>
                      <div class="input-field col s4">
                        <input id="contact" type="text" value="<?=$student->parents_no;?>">
                        <label for="contact">Mobile Number</label>
                      </div>
                    </div>
                    <div class="row">
                      <div class="input-field col s4">
                        <input id="email" type="email" autocomplete="no" value="<?=$student->email;?>">
                        <label for="email">Email</label>
                      </div>
                      <div class="input-field col s4">
                        <input id="password" type="password" autocomplete="no"  value="<?=$student->password;?>">
                        <label for="password">Password</label>
                      </div>
                      <div class="input-field col s4">
                        <input id="prn" type="text" autocomplete="no" value="<?=$student->prn_no;?>">
                        <label for="prn">PRN Number</label>
                      </div>
                    </div>
                    <div class="row">
                      <div class="input-field col s4">
                        <select id="branch">
                          <option value="" disabled selected>Choose your Branch</option>
                          <option <?php if ($student->branch == "CSE") { echo "selected"; } ?> value="CSE">CSE</option>
                          <option <?php if ($student->branch == "IT") { echo "selected"; } ?> value="IT">IT</option>
                          <option <?php if ($student->branch == "MECH") { echo "selected"; } ?> value="MECH">MECH</option>
                          <option <?php if ($student->branch == "CIVIL") { echo "selected"; } ?> value="CIVIL">CIVIL</option>
                          <option <?php if ($student->branch == "EXTC") { echo "selected"; } ?> value="EXTC">EXTC</option>
                        </select>
                        <label>Branch</label>
                      </div>                        
                      <div class="input-field col s4">
                        <select id="year">
                          <option value="" disabled selected>Choose your year</option>
                          <option <?php if ($student->year == "1") { echo "selected"; } ?> value="1">First Year</option>
                          <option <?php if ($student->year == "2") { echo "selected"; } ?> value="2">Second Year</option>
                          <option <?php if ($student->year == "3") { echo "selected"; } ?> value="3">Third Year</option>
                          <option <?php if ($student->year == "4") { echo "selected"; } ?> value="4">Final Year</option>
                        </select>
                        <label>Select Year</label>
                      </div>                        
                      <div class="input-field col s4">
                        <input id="dob" type="date" class="datepicker">
                        <label for="dob">DOB</label>
                      </div>
                    </div>
                    <div class="row">
                      <div class="input-field col s12">
                        <textarea id="aboutme" class="materialize-textarea" length="120"><?=$student->aboutme;?></textarea>
                        <label for="aboutme">Address</label>
                      </div>
                      <div class="row">
                        <div class="input-field col s12">
                          <a id="btnSave" class="btn cyan waves-effect waves-light right">Save<i class="mdi-content-send right"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          </div>
          <br>
          <!-- Floating Action Button -->
        <!--end container-->