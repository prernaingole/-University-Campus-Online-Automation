 <!--start container-->
 <div class="container">
          <div class="section">
            <div class="row">
              <?php if ($notifications) {
                foreach ($notifications as $notification) {
                ?>
                  <div class="col s12 m4 l3">
                            <div class="card deep-purple">
                      <div class="card-content white-text">
                        <span class="card-title white-text darken-1"><?=$notification->notification_title;?></span>
                        <p><?=$notification->notification_text;?></p>
                      </div>
                    </div>
                    </div>
                <?php } 
              } else { ?>
            <p class="caption">No notifications</p>
            <div class="divider"></div>
              <?php }
                ?>
            </div>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
          </div>
          <!-- Floating Action Button -->
        <!--end container-->