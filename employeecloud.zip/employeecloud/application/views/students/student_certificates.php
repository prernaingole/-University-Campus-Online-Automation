<!--start container-->
<div class="container">
  <div class="section">

    <p class="caption">Upload Your certificates, achievements here.</p>
    <div class="divider"></div>
    <div class="row section">
      <div class="col s12 m4 l3">
        <form method="POST" enctype="multipart/form-data">
          <input id="certificateHolder" type="file" name="image" />
          <br><br>
          <a href class="btn btn-primary" id="btnUploadCertificate"> Upload Certificate</a>
        </form>
      </div>
      <?php 
      if ($certificates) {
      ?>
      <div id="striped-table">
        <h4 class="header">Your Certificates and Achievements</h4>
        <div class="row">
          <div class="col s12">
            <table class="striped">
              <thead>
                <tr>
                  <th data-field="id">Name</th>
                  <th data-field="price">View / Download</th>
                </tr>
              </thead>
              <tbody>
                  <?php foreach ($certificates as $certificate) { ?>
                    <tr>
                      <td><?=$certificate->certificate_name;?></td>
                      <td><a href="<?=$certificate->certificate_details;?>" class="btn btn-primary" download="">Download Certificate</a></td>
                    </tr>
                  <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <?php } ?>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  </div>
  <!-- Floating Action Button -->
  <!--end container-->
  <!--Default version-->