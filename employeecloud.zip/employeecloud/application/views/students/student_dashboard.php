<!--start container-->
<div class="container">
  <div class="section">
    <!--<div id="card-stats">
      <div class="row">
        <div class="col s12 m6 l4">
          <div class="card">
            <div class="card-content  green white-text">
              <p class="card-stats-title"><i class="mdi-social-group-add"></i> Total Companies</p>
              <h4 class="card-stats-number">2</h4>
              </p>
            </div>
            <div class="card-action  green darken-2">
              <div id="clients-bar" class="center-align"><canvas width="227" height="25"
                  style="display: inline-block; width: 227px; height: 25px; vertical-align: top;"></canvas></div>
            </div>
          </div>
        </div>
        <div class="col s12 m6 l4">
          <div class="card">
            <div class="card-content pink lighten-1 white-text">
              <p class="card-stats-title"><i class="mdi-editor-insert-drive-file"></i> Total Certifications</p>
              <h4 class="card-stats-number">3</h4>
              </p>
            </div>
            <div class="card-action  pink darken-2">
              <div id="invoice-line" class="center-align"><canvas width="265" height="25"
                  style="display: inline-block; width: 265px; height: 25px; vertical-align: top;"></canvas></div>
            </div>
          </div>
        </div>
        <div class="col s12 m6 l4">
          <div class="card">
            <div class="card-content blue-grey white-text">
              <p class="card-stats-title"><i class="mdi-action-trending-up"></i> Total Achievements</p>
              <h4 class="card-stats-number">4</h4>
            </div>
            <div class="card-action blue-grey darken-2">
              <div id="profit-tristate" class="center-align"><canvas width="227" height="25"
                  style="display: inline-block; width: 227px; height: 25px; vertical-align: top;"></canvas></div>
            </div>
          </div>
        </div>
      </div>
    </div>-->
    <h1>Welcome, <?=$student->name;?></h1>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  </div>

  
</div>
<!--end container-->
