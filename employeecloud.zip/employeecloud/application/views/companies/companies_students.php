<!--start container-->
<div class="container">
  <div class="section">
    <!--DataTables example-->
    <div id="table-datatables">
      <h4 class="header">Students List</h4>
      <div class="row">
        <div class="col s12">
          <table id="data-table-simple" class="responsive-table display" cellspacing="0">
            <thead>
              <tr>
                <th>Name</th>
                <th>E-mail</th>
                <th>Branch</th>
                <th>Contact no.</th>
                <th>Action</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>Name</th>
                <th>E-mail</th>
                <th>Branch</th>
                <th>Contact no.</th>
                <th>Action</th>
              </tr>
            </tfoot>
           <tbody>
              <?php foreach($students as $student){ ?>
              <tr>
                <td><?php echo $student->name; ?></td>
                <td><?php echo $student->email; ?></td>
                <td><?php echo $student->branch; ?></td>
                <td><?php echo $student->contact_no; ?></td>
                <td>
                    <a class="btn-floating waves-effect waves-light purple"><i class="mdi-action-pageview"></i></a>
                </td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<!--end container-->