<!--start container-->
<div class="container">
  <div class="section">
    <div class="row">
      <div class="col s12 m12 l12">
        <div class="card-panel">
          <h4 class="header2">Basic Details</h4>
          <div class="row">
            <form class="col s12">
              <div class="row">
                <div class="input-field col s4">
                  <input id="full_name" type="text" value="">
                  <label for="full_name">Company Name</label>
                </div>
                <div class="input-field col s4">
                  <input id="parents_no" type="password" value="">
                  <label for="parents_no">Username</label>
                </div>
                <div class="input-field col s4">
                  <input id="contact" type="password" value="">
                  <label for="contact">Password</label>
                </div>
              </div>
              
              <div class="row">
                <div class="input-field col s6">
                  <input id="dob" type="text" value="">
                  <label for="dob">Company Address</label>
                </div>
              
                <div class="input-field col s6">
                  <input id="aboutme" type="text"></input>
                  <label for="aboutme">Company Contact</label>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <a id="btnSave" class="btn cyan waves-effect waves-light right">Save<i
                        class="mdi-content-send right"></i>
                    </a>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--end container-->