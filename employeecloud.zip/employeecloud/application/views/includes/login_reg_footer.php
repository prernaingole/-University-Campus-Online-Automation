 <!-- ================================================
    Scripts
    ================================================ -->

  <!-- jQuery Library -->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/jquery-1.11.2.min.js"></script>
  <!--materialize js-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/materialize.js"></script>
  <!--prism-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/prism/prism.js"></script>
  <!--scrollbar-->
  <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

      <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/custom-script.js"></script>

    <script>
    $(document).ready(function () {
        $("#btnRegister").click(function (e) { 
            e.preventDefault();
            var errors = 0;
            var name = $("#name").val();
            var username = $("#username").val();
            var password = $("#password").val();
            var confirmpassword = $("#confirm_password").val();
            var email = $("#email").val();
            var contact = $("#contact").val();
            var aadhar = $("#aadhar").val();
            var gender = $("input[name='gender']:checked"). val();
            //Validations
            if (name.length < 12) {
                Materialize.toast('<span>Full name can not be less than 12 characters.</span>', 3500);
                errors++; 
            }

            if (username.length < 5) {
                Materialize.toast('<span>Username can not be less than 5 characters.</span>', 3500);
                errors++; 
            }

            if (password.length < 5) {
                Materialize.toast('<span>Password can not be less than 5 characters.</span>', 3500);
                errors++; 
            }

            if (confirmpassword.length < 5 || confirmpassword != password) {
                Materialize.toast('<span>Confirm Password and password must be same.</span>', 3500);
                errors++; 
            }

            if (aadhar.length < 12) {
                Materialize.toast('<span>Please enter valid Aadhar UID</span>', 3500);
                errors++; 
            }

            if (contact.length < 10) {
                Materialize.toast('<span>Please enter valid Mobile Number</span>', 3500);
                errors++; 
            }

            if (!validateEmail(email) || email.length < 15) {
            $("#email").val("");
            Materialize.toast('<span>Invalid E-mail</span>', 3500);
            email="";
        }

            if (errors==0) {
                $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>ajax/registerStudent",
                data: {'name':name,'contact_no':contact,'username':username,'password':password,'email':email,'uid':aadhar},
                dataType: "JSON",
                success: function (response) {
                    Materialize.toast('<span>Registered Successfully</span>', 1500);    
                    setTimeout(function() {
                        window.location.href = "<?php echo base_url();?>";
                     }, 1000);
                }
            });
            } 


        });
       
        $("#btnRegisterCompany").click(function (e) { 
            e.preventDefault();
            var errors = 0;
            var name = $("#name").val();
            var username = $("#username").val();
            var password = $("#password").val();
            var address = $("#address").val();
            var contact = $("#contact").val();

            if (name.length < 5) {
                Materialize.toast('<span>Company name can not be less than 5 characters.</span>', 3500);
                errors++; 
            }
            if (address.length < 15) {
                Materialize.toast('<span>Address can not be less than 15 characters.</span>', 3500);
                errors++; 
            }
            if (username.length < 5) {
                Materialize.toast('<span>Username can not be less than 5 characters.</span>', 3500);
                errors++; 
            }
            if (password.length < 5) {
                Materialize.toast('<span>Password can not be less than 5 characters.</span>', 3500);
                errors++; 
            }
            if (contact.length < 10) {
                Materialize.toast('<span>Contact can not be less than 10 characters.</span>', 3500);
                errors++; 
            }

            if (errors != 0) {
                $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>ajax/addCompany",
                data: {'company_name':name,'company_username':username,'company_password':password,'company_address':address,'company_contact':contact,'uid':aadhar},
                dataType: "JSON",
                success: function (response) {
                    Materialize.toast('<span>Registered Successfully</span>', 1500);    
                    setTimeout(function() {
                        window.location.href = "<?php echo base_url();?>";
                     }, 1000);
                }
            });
            }

        });
       
        $("#btnLogin").click(function (e) { 
            e.preventDefault();
            var username = $("#username").val(); // Store username
            var password = $("#password").val(); // Store password
            var loginAs = $("#loginAs").val(); // Store Type
            var role;
            var errors = 0;


            if (username.length < 5) {
                Materialize.toast('<span>Please enter valid username</span>', 3500);
                errors++; 
            }
            if (password.length < 5) {
                Materialize.toast('<span>Please enter valid password.</span>', 3500);
                errors++; 
            }         
            if ($("#loginAs").val() == null) {
               Materialize.toast('<span>Please select Login Role</span>', 3500);
               errors++; 
            }

            if (errors == 0) {
                if (loginAs=="1") {
                role = "students";
            } else if (loginAs=="2") {
                role = "companies";
            }
            else if (loginAs=="3") {
                role = "universities";
            }
            else if (loginAs=="4") {
                role = "admin";
            }
            else if (loginAs=="5") {
                role = "nad";
            }
                // Difference between get and post
                // search on google now
                // 73 INR - 1 USD
            $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>ajax/login",
                data: {'username':username,'password':password,'role':role},
                dataType: "JSON",
                success: function (response) {
                   if (response.status=="1") {
                    Materialize.toast('<span>Logging in.</span>', 1500);    
                    setTimeout(function() {
                        window.location.href = "<?php echo base_url();?>" + role;
                     }, 1000);
                   }
                   else {
                    Materialize.toast('<span>Wrong username / password </span>', 1500);    
                   }
                }
            });
            }
       });
    });

    function validateEmail($email) {
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  return emailReg.test( $email );
}
    </script>

</body>

</html>