</section>
      <!-- END CONTENT -->

      <!-- //////////////////////////////////////////////////////////////////////////// -->
      <!-- START RIGHT SIDEBAR NAV-->
      <aside id="right-sidebar-nav">
        <ul id="chat-out" class="side-nav rightside-navigation">
            <li class="li-hover">
            <a href="#" data-activates="chat-out" class="chat-close-collapse right"><i class="mdi-navigation-close"></i></a>
            <div id="right-search" class="row">
                <form class="col s12">
                    <div class="input-field">
                        <i class="mdi-action-search prefix"></i>
                        <input id="icon_prefix" type="text" class="validate">
                        <label for="icon_prefix">Search</label>
                    </div>
                </form>
            </div>
            </li>
            <li class="li-hover">
                <ul class="chat-collapsible" data-collapsible="expandable">
                <li>
                    <div class="collapsible-header teal white-text active"><i class="mdi-social-whatshot"></i>Recent Activity</div>
                    <div class="collapsible-body recent-activity">
                        <div class="recent-activity-list chat-out-list row">
                            <div class="col s3 recent-activity-list-icon"><i class="mdi-action-add-shopping-cart"></i>
                            </div>
                            <div class="col s9 recent-activity-list-text">
                                <a href="#">just now</a>
                                <p>Jim Doe Purchased new equipments for zonal office.</p>
                            </div>
                        </div>
                        <div class="recent-activity-list chat-out-list row">
                            <div class="col s3 recent-activity-list-icon"><i class="mdi-device-airplanemode-on"></i>
                            </div>
                            <div class="col s9 recent-activity-list-text">
                                <a href="#">Yesterday</a>
                                <p>Your Next flight for USA will be on 15th August 2015.</p>
                            </div>
                        </div>
                        <div class="recent-activity-list chat-out-list row">
                            <div class="col s3 recent-activity-list-icon"><i class="mdi-action-settings-voice"></i>
                            </div>
                            <div class="col s9 recent-activity-list-text">
                                <a href="#">5 Days Ago</a>
                                <p>Natalya Parker Send you a voice mail for next conference.</p>
                            </div>
                        </div>
                        <div class="recent-activity-list chat-out-list row">
                            <div class="col s3 recent-activity-list-icon"><i class="mdi-action-store"></i>
                            </div>
                            <div class="col s9 recent-activity-list-text">
                                <a href="#">Last Week</a>
                                <p>Jessy Jay open a new store at S.G Road.</p>
                            </div>
                        </div>
                        <div class="recent-activity-list chat-out-list row">
                            <div class="col s3 recent-activity-list-icon"><i class="mdi-action-settings-voice"></i>
                            </div>
                            <div class="col s9 recent-activity-list-text">
                                <a href="#">5 Days Ago</a>
                                <p>Natalya Parker Send you a voice mail for next conference.</p>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="collapsible-header light-blue white-text active"><i class="mdi-editor-attach-money"></i>Sales Repoart</div>
                    <div class="collapsible-body sales-repoart">
                        <div class="sales-repoart-list  chat-out-list row">
                            <div class="col s8">Target Salse</div>
                            <div class="col s4"><span id="sales-line-1"></span>
                            </div>
                        </div>
                        <div class="sales-repoart-list chat-out-list row">
                            <div class="col s8">Payment Due</div>
                            <div class="col s4"><span id="sales-bar-1"></span>
                            </div>
                        </div>
                        <div class="sales-repoart-list chat-out-list row">
                            <div class="col s8">Total Delivery</div>
                            <div class="col s4"><span id="sales-line-2"></span>
                            </div>
                        </div>
                        <div class="sales-repoart-list chat-out-list row">
                            <div class="col s8">Total Progress</div>
                            <div class="col s4"><span id="sales-bar-2"></span>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="collapsible-header red white-text"><i class="mdi-action-stars"></i>Favorite Associates</div>
                    <div class="collapsible-body favorite-associates">
                        <div class="favorite-associate-list chat-out-list row">
                            <div class="col s4"><img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="" class="circle responsive-img online-user valign profile-image">
                            </div>
                            <div class="col s8">
                                <p>Eileen Sideways</p>
                                <p class="place">Los Angeles, CA</p>
                            </div>
                        </div>
                        <div class="favorite-associate-list chat-out-list row">
                            <div class="col s4"><img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="" class="circle responsive-img online-user valign profile-image">
                            </div>
                            <div class="col s8">
                                <p>Zaham Sindil</p>
                                <p class="place">San Francisco, CA</p>
                            </div>
                        </div>
                        <div class="favorite-associate-list chat-out-list row">
                            <div class="col s4"><img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="" class="circle responsive-img offline-user valign profile-image">
                            </div>
                            <div class="col s8">
                                <p>Renov Leongal</p>
                                <p class="place">Cebu City, Philippines</p>
                            </div>
                        </div>
                        <div class="favorite-associate-list chat-out-list row">
                            <div class="col s4"><img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="" class="circle responsive-img online-user valign profile-image">
                            </div>
                            <div class="col s8">
                                <p>Weno Carasbong</p>
                                <p>Tokyo, Japan</p>
                            </div>
                        </div>
                        <div class="favorite-associate-list chat-out-list row">
                            <div class="col s4"><img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="" class="circle responsive-img offline-user valign profile-image">
                            </div>
                            <div class="col s8">
                                <p>Nusja Nawancali</p>
                                <p class="place">Bangkok, Thailand</p>
                            </div>
                        </div>
                    </div>
                </li>
                </ul>
            </li>
        </ul>
      </aside>
      <!-- LEFT RIGHT SIDEBAR NAV-->

    </div>
    <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->



  <!-- //////////////////////////////////////////////////////////////////////////// -->

  <!-- START FOOTER -->
  <footer class="page-footer">
    <div class="footer-copyright">
    <div class="container">
        <span>Copyright © 2018 All rights reserved.</span>
        </div>
    </div>
  </footer>
  <!-- END FOOTER -->



    <!-- ================================================
    Scripts
    ================================================ -->
    
    <!-- jQuery Library -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/jquery-1.11.2.min.js"></script>    
    <!--materialize js-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/materialize.js"></script>
    <!--prism
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/prism/prism.js"></script>-->
    <!--scrollbar-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!-- chartist -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/chartist-js/chartist.min.js"></script>   
    
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/custom-script.js"></script>
    <script>
    $(document).ready(function () {
        
        $("#btnSave").click(function (e) { 
            var name = $("#full_name").val();
            var parents_no = $("#parents_no").val();
            var contact = $("#contact").val();
            var college = $("#college").val();
            var branch = $("#branch").val();
            var year = $("#year").val();
            var email = $("#email").val();
            var password = $("#password").val();
            var dob = $("#dob").val();
            var prn = $("#prn").val();
            var about = $("#aboutme").val();

            $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>ajax/updateStudent",
                data: {'name':name,'parents_no':parents_no,'contact_no':contact,'college':college,'branch':branch,'year':year,'email':email,'password':password,'dob':dob,'aboutme':about,'prn_no':prn},
                dataType: "JSON",
                success: function (response) {
                    Materialize.toast("Profile Updated.",1500);
                }
            });
            
        });



        $("#ssc_marks").keyup(function (e) { 
            e.preventDefault();
            calcSSCPercentage();
        });

        $("#hsc_marks").keyup(function (e) { 
            e.preventDefault();
            calcHSCPercentage();
        });

        $("#diploma_marks").keyup(function (e) { 
            e.preventDefault();
            calcdiplomaPercentage();
        });

        $("#be_marks").keyup(function (e) { 
            e.preventDefault();
            calcBEPercentage();
        });

        $("#btnUpdateEduInfo").click(function (e) { 
            e.preventDefault();
            //SSC DETAILS
            var ssc_institute = $("#ssc_institute").val();
            var ssc_yop = $("#ssc_yop").val();
            var ssc_total = $("#ssc_total").val();
            var ssc_marks = $("#ssc_marks").val();
            var ssc_percentage = $("#ssc_percentage").html();
            //HSC DETAILS
            var hsc_institute = $("#hsc_institute").val();
            var hsc_branch = $("#hsc_branch").val();
            var hsc_yop = $("#hsc_yop").val();
            var hsc_total = $("#hsc_total").val();
            var hsc_marks = $("#hsc_marks").val();
            var hsc_percentage = $("#hsc_percentage").html();

            //Diploma DETAILS
            var diploma_institute = $("#diploma_institute").val();
            var diploma_branch = $("#diploma_branch").val();
            var diploma_yop = $("#diploma_yop").val();
            var diploma_total = $("#diploma_total").val();
            var diploma_marks = $("#diploma_marks").val();
            var diploma_percentage = $("#diploma_percentage").html();

            //BE DETAILS
            var be_institute = $("#be_institute").val();
            var be_branch = $("#be_branch").val();

            //Sem wise marks
            var be_sem1_marks = $("#be_marks_1").val();
            var be_sem1_percentage = $("#be_percentage_1").val();
            var be_sem1_sgpa = $("#be_sgpa_1").val();

            var be_sem2_marks = $("#be_marks_2").val();
            var be_sem2_percentage = $("#be_percentage_2").val();
            var be_sem2_sgpa = $("#be_sgpa_2").val();

            var be_sem3_marks = $("#be_marks_3").val();
            var be_sem3_percentage = $("#be_percentage_3").val();
            var be_sem3_sgpa = $("#be_sgpa_3").val();

            var be_sem4_marks = $("#be_marks_4").val();
            var be_sem4_percentage = $("#be_percentage_4").val();
            var be_sem4_sgpa = $("#be_sgpa_4").val();

            var be_sem5_marks = $("#be_marks_5").val();
            var be_sem5_percentage = $("#be_percentage_5").val();
            var be_sem5_sgpa = $("#be_sgpa_5").val();

            var be_sem6_marks = $("#be_marks_6").val();
            var be_sem6_percentage = $("#be_percentage_6").val();
            var be_sem6_sgpa = $("#be_sgpa_6").val();

            var be_sem7_marks = $("#be_marks_7").val();
            var be_sem7_percentage = $("#be_percentage_7").val();
            var be_sem7_sgpa = $("#be_sgpa_7").val();

            var be_sem8_marks = $("#be_marks_8").val();
            var be_sem8_percentage = $("#be_percentage_8").val();
            var be_sem8_sgpa = $("#be_sgpa_8").val();

            $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>ajax/updateEducationalInfo",
                data: {'ssc_institute':ssc_institute,'ssc_yop':ssc_yop,'ssc_total':ssc_total,'ssc_marks':ssc_marks,'ssc_percentage':ssc_percentage,
                'hsc_branch':hsc_branch, 'hsc_institute':hsc_institute,'hsc_yop':hsc_yop,'hsc_total':hsc_total,'hsc_marks':hsc_marks,'hsc_percentage':hsc_percentage,
                'diploma_branch':diploma_branch, 'diploma_institute':diploma_institute,'diploma_yop':diploma_yop,'diploma_total':diploma_total,'diploma_marks':diploma_marks,'diploma_percentage':diploma_percentage,
                'be_branch':be_branch, 'be_institute':be_institute,'be_sem1_marks':be_sem1_marks,'be_sem1_percentage':be_sem1_percentage,'be_sem1_sgpa':be_sem1_sgpa,'be_sem2_marks':be_sem2_marks,'be_sem2_percentage':be_sem2_percentage,'be_sem2_sgpa':be_sem2_sgpa,
                'be_sem3_marks':be_sem3_marks,'be_sem3_percentage':be_sem3_percentage,'be_sem3_sgpa':be_sem3_sgpa,'be_sem4_marks':be_sem4_marks,'be_sem4_percentage':be_sem4_percentage,'be_sem4_sgpa':be_sem4_sgpa,
                'be_sem5_marks':be_sem5_marks,'be_sem5_percentage':be_sem5_percentage,'be_sem5_sgpa':be_sem5_sgpa,'be_sem6_marks':be_sem6_marks,'be_sem6_percentage':be_sem6_percentage,'be_sem6_sgpa':be_sem6_sgpa,
                'be_sem7_marks':be_sem7_marks,'be_sem7_percentage':be_sem7_percentage,'be_sem7_sgpa':be_sem7_sgpa,'be_sem8_marks':be_sem8_marks,'be_sem8_percentage':be_sem8_percentage,'be_sem8_sgpa':be_sem8_sgpa,
            },
                dataType: "JSON",
                success: function (response) {
                    Materialize.toast("Details Updated.",1500);
//                    location.reload(true); 
                }
            });


            
        });


        $("#btnAddAchievement").click(function (e) { 
            e.preventDefault();
            var title = $("#title").val();
            var givenby = $("#givenby").val();
            var details = $("#details").val();

            $.ajax({
                type: "POST",
                url: "<?php echo base_url();?>ajax/addAchievement",
                data: {'title':title,'givenby':givenby,'details':details},
                dataType: "JSON",
                success: function (response) {
                    Materialize.toast("Achievement Added.",1500);
                    location.reload(true); 
                }
            });
            
        });
       
        $("#btnUploadCertificate").click(function (e) { 
            e.preventDefault();
            var formData = new FormData();
            formData.append('image', $('input[type=file]')[0].files[0]); 

            $.ajax({
                type: "POST",
                contentType: false, // NEEDED, DON'T OMIT THIS (requires jQuery 1.6+)
                processData: false, // NEEDED, DON'T OMIT THIS
                url: "<?php echo base_url();?>ajax/addCertificate",
                data: formData,
                dataType: "JSON",
                success: function (response) {
                    Materialize.toast("Certificate Added.",1500);
                    location.reload(true); 
                }
            });
            
        });

    });
    function calcSSCPercentage() { 
            var total = $("#ssc_total").val();
            var marks = $("#ssc_marks").val();
            var percentage = (marks / total) * 100;
            percentage = 
            $("#ssc_percentage").html(percentage + ' %');
     }
    function calcHSCPercentage() { 
            var total = $("#hsc_total").val();
            var marks = $("#hsc_marks").val();
            var percentage = (marks / total) * 100;
            $("#hsc_percentage").html(percentage + ' %');
     }
    function calcdiplomaPercentage() { 
            var total = $("#diploma_total").val();
            var marks = $("#diploma_marks").val();
            var percentage = (marks / total) * 100;
            $("#diploma_percentage").html(percentage + ' %');
     }
    function calcBEPercentage() { 
            var total = $("#be_total").val();
            var marks = $("#be_marks").val();
            var percentage = (marks / total) * 100;
            $("#be_percentage").html(percentage + ' %');
     }
    </script>
</body>

</html>