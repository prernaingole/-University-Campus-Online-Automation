<div id="login-page" class="row">
  <div class="col s12 z-depth-4 card-panel">
    <form class="login-form">
      <div class="row">
        <div class="input-field col s12 center">
          <h4>Company Registration</h4>
          <p class="center">Create your Company profile today !</p>
        </div>
      </div>
      <div class="row margin">
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="name" type="text">
          <label for="name" class="center-align">Company Name</label>
        </div>
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="address" type="text">
          <label for="address" class="center-align">Company Address</label>
        </div>
        <div class="input-field col s12">
          <i class="mdi-social-person-outline prefix"></i>
          <input id="contact" type="text" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10">
          <label for="contact" class="center-align">Company Contact</label>
        </div>
      </div>
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-social-person-outline prefix"></i>
            <input id="username" type="text">
            <label for="username">Username</label>
          </div>
          <div class="input-field col s12">
            <i class="mdi-action-lock-outline prefix"></i>
            <input id="password" type="password">
            <label for="password">Password</label>
          </div>
        </div>

        <div class="row">
          <div class="input-field col s12">
            <a id="btnRegisterCompany" class="btn waves-effect waves-light col s12">Register Now</a>
          </div>
          <div class="input-field col s12">
            <p class="margin center medium-small sign-up">Already have an account? <a
                href="<?php echo base_url();?>login">Login</a></p>
          </div>
        </div>
    </form>
  </div>
</div>