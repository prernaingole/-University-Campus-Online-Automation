 <!--start container-->
 <div class="container">
          <div class="section">

            <p class="caption">A Simple Blank Page to use it for your custome design and elements.</p>
            <div class="divider"></div>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
          </div>
          <!-- Floating Action Button -->
            <!-- Floating Action Button -->
            <div class="fixed-action-btn" style="bottom: 50px; right: 19px;">
                <a class="modal-trigger btn-floating btn-large tooltipped" data-position="left" data-delay="50" data-tooltip="Add New Company" href="#modalAddCompany">
                  <i class="mdi-content-add-circle-outline"></i>
                </a>
            </div>
            <!-- Floating Action Button -->
        </div>
        <!--end container-->


        <div id="modalAddCompany" class="modal">
                  <div class="modal-content">
                  <h4 class="header">Add Company</h4>
              <div class="row">
                <div class="col s12 m12 l12">
                  <div class="row">
                    <form class="col s12">
                      <div class="row">
                        <div class="input-field col s6">
                          <input id="company_name" type="text" class="validate">
                          <label for="company_name">Company Name</label>
                        </div>
                        <div class="input-field col s6">
                          <input id="company_address" type="text" class="validate">
                          <label for="company_address">Company Address</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s6">
                          <input id="company_username" type="password" class="validate">
                          <label for="company_username">Username</label>
                        </div>
                        <div class="input-field col s6">
                          <input id="company_password" type="password" class="validate">
                          <label for="company_password">Password</label>
                        </div>
                        <div class="input-field col s6">
                          <input type="text" id="company_contact" class="validate">
                          <label for="company_contact">Company Contact:</label>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
                  </div>
                  <div class="modal-footer">
                    <a href="#" class="waves-effect waves-red btn-flat modal-action modal-close">Close</a>
                    <a href="#" class="waves-effect waves-green btn btn-primary modal-action">Add Company</a>
                  </div>
                </div>
