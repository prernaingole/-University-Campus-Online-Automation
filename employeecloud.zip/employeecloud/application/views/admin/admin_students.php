<!--start container-->
<div class="container">
  <div class="section">
    <p class="caption">Students Will Appear Here</p>
    <div class="divider"></div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  </div>
  <!-- Floating Action Button -->
  <div class="fixed-action-btn" style="bottom: 50px; right: 19px;">
    <a class="modal-trigger btn-floating btn-large tooltipped" data-position="left" data-delay="50"
      data-tooltip="Add New Company" href="#modalAddCompany">
      <i class="mdi-content-add-circle-outline"></i>
    </a>
  </div>
  <!-- Floating Action Button -->
</div>
<!--end container-->
<div id="modalAddCompany" class="modal">
  <div class="modal-content">
    <h4 class="header">Add Student</h4>
    <div class="row">
      <div class="col s12 m12 l12">
        <div class="row">
          <form class="col s12">
            <div class="row">
              <div class="input-field col s6">
                <input id="company_name" type="text" class="validate">
                <label for="company_name">Student Name</label>
              </div>
              <div class="input-field col s6">
                <input id="company_address" type="text" class="validate">
                <label for="company_address">E-mail</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s12">
                <input id="company_username" type="text" class="validate">
                <label for="company_username">College</label>
              </div>
              <div class="input-field col s6">
                <input id="company_password" type="password" class="validate">
                <label for="company_password">Username</label>
              </div>
              <div class="input-field col s6">
                <input id="company_contact" type="password" class="validate">
                <label for="company_contact">Password</label>
              </div>
            </div>
            <div class="row">
              <div class="input-field col s6">
                <input id="company_username" type="text" class="validate">
                <label for="company_username">Branch</label>
              </div>
              <div class="input-field col s6">
                <input id="company_password" type="text" class="validate">
                <label for="company_password">Year</label>
              </div>
              <div class="input-field col s6">
                <input type="text" id="company_contact" class="validate">
                <label for="company_contact">Contact no.</label>
              </div>
              <div class="input-field col s6">
                <input type="text" id="company_contact" class="validate">
                <label for="company_contact">Parent no.</label>
              </div>
              <div class="input-field col s6">
                <input type="text" id="company_contact" class="validate">
                <label for="company_contact">DOB</label>
              </div>
              <div class="input-field col s12">
                <input type="text" id="company_contact" class="validate">
                <label for="company_contact">About me</label>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <a href="#" class="waves-effect waves-red btn-flat modal-action modal-close">Close</a>
    <a href="#" class="waves-effect waves-green btn btn-primary modal-action">Add Company</a>
  </div>
</div>