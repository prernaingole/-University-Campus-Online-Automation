<!--start container-->
<div class="container">
  <div class="section">

    <div class="row">
      <?php if ($notifications) {
    foreach ($notifications as $notification) {
        ?>
      <div class="col s12 m4 l3">
        <div class="card deep-purple">
          <div class="card-content white-text">
            <span class="card-title white-text darken-1"><?=$notification->notification_title;?></span>
            <p><?=$notification->notification_text;?></p>
          </div>
        </div>
      </div>
      <?php }
} else {?>
      <p class="caption">No notifications</p>
      <div class="divider"></div>
      <?php }
?>
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  </div>
  <!-- Floating Action Button -->
  <div class="fixed-action-btn" style="bottom: 50px; right: 19px;">
    <a class="modal-trigger btn-floating btn-large tooltipped" data-position="left" data-delay="50"
      data-tooltip="Add New Company" href="#modalAddCompany">
      <i class="mdi-content-add-circle-outline"></i>
    </a>
  </div>
  <!-- Floating Action Button -->
</div>
<!--end container-->
<div id="modalAddCompany" class="modal">
  <div class="modal-content">
    <h4 class="header">Add Notification</h4>
    <div class="row">
      <div class="col s12 m12 l12">
        <div class="row">
          <form class="col s12">
            <div class="row">
              <div class="input-field col s12">
                <input id="company_name" type="text" class="validate">
                <label for="company_name">Notification Title</label>
              </div>
              <div class="input-field col s12">
                <input id="company_address" type="text" class="validate">
                <label for="company_address">Notification Text</label>
              </div>
            </div>
            </form>
        </div>
      </div>
    </div>
  </div>
  <div class="modal-footer">
    <a href="#" class="waves-effect waves-red btn-flat modal-action modal-close">Close</a>
    <a href="#" class="waves-effect waves-green btn btn-primary modal-action">Add Notification</a>
  </div>
</div>