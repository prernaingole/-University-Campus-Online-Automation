 <!--start container-->
 <div class="container">
          <div class="section">
          <div class="row">
      <?php if ($companies) {
    foreach ($companies as $company) {
        ?>
        <div class="col s12 m4 l3">
                  <div class="card">
                      <div class="card-image waves-effect waves-block waves-light">
                        <img class="activator" src="<?php echo base_url(); ?>assets/images/company.png" alt="office">
                      </div>
                      <div class="card-content">
                        <span class="card-title activator grey-text text-darken-4"><?=$company->name;?><i class="mdi-navigation-more-vert right"></i></span>
                        <p><a href="tel:<?=$company->company_contact;?>">Call <?=$company->company_contact;?></a>
                        </p>
                      </div>
                      <div class="card-reveal">
                        <span class="card-title grey-text text-darken-4">Address of <?=$company->name;?><i class="mdi-navigation-close right"></i></span>
                        <p><?=$company->company_address;?></p>
                      </div>
                    </div>
                </div>

      <?php }
} else {?>
      <p class="caption">No Companies Found</p>
      <div class="divider"></div>
      <?php }
?>
 </div>
            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
          </div>
          <!-- Floating Action Button -->
            <div class="fixed-action-btn" style="bottom: 50px; right: 19px;">
                <a class="modal-trigger btn-floating btn-large tooltipped" data-position="left" data-delay="50" data-tooltip="Add New Company" href="#modalAddCompany">
                  <i class="mdi-content-add-circle-outline"></i>
                </a>
            </div>
            <!-- Floating Action Button -->
        </div>
        <!--end container-->


        <div id="modalAddCompany" class="modal">
                  <div class="modal-content">
                  <h4 class="header">Add Company</h4>
              <div class="row">
                <div class="col s12 m12 l12">
                  <div class="row">
                    <form class="col s12">
                      <div class="row">
                        <div class="input-field col s6">
                          <input id="company_name" type="text" class="validate">
                          <label for="company_name">Company Name</label>
                        </div>
                        <div class="input-field col s6">
                          <input id="company_address" type="text" class="validate">
                          <label for="company_address">Company Address</label>
                        </div>
                      </div>
                      <div class="row">
                        <div class="input-field col s6">
                          <input id="company_username" type="text" class="validate">
                          <label for="company_username">Username</label>
                        </div>
                        <div class="input-field col s6">
                          <input id="company_password" type="password" class="validate">
                          <label for="company_password">Password</label>
                        </div>
                        <div class="input-field col s6">
                          <input type="text" id="company_contact" class="validate">
                          <label for="company_contact">Company Contact:</label>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
                  </div>
                  <div class="modal-footer">
                    <a href="#" class="waves-effect waves-red btn-flat modal-action modal-close">Close</a>
                    <a href id="btnAddCompanies"  class="waves-effect waves-green btn btn-primary modal-action">Add Company</a>
                  </div>
                </div>
