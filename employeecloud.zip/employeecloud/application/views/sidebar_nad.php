 <!-- START MAIN -->
 <div id="main">
    <!-- START WRAPPER -->
    <div class="wrapper">

      <!-- START LEFT SIDEBAR NAV-->
      <aside id="left-sidebar-nav">
        <ul id="slide-out" class="side-nav fixed leftside-navigation">
            <li class="user-details cyan darken-2">
            <div class="row">
                <div class="col col s4 m4 l4">
                    <img src="<?php echo base_url();?>assets/images/avatar.jpg" alt="" class="circle responsive-img valign profile-image">
                </div>
                <div class="col col s8 m8 l8">
                    <ul id="profile-dropdown" class="dropdown-content">
                    <li><a href="<?php echo base_url();?>welcome/logout"><i class="mdi-hardware-keyboard-tab"></i> Logout</a>
                        </li>
                    </ul>
                    <a class="btn-flat dropdown-button waves-effect waves-light white-text profile-btn" href="#" data-activates="profile-dropdown"><?php echo $this->session->name;?><i class="mdi-navigation-arrow-drop-down right"></i></a>
                    <p class="user-roal">nad</p>
                </div>
            </div>
            </li>
            <li class="bold"><a href="<?php echo base_url();?>nad" class="waves-effect waves-cyan"><i class="mdi-action-dashboard"></i> Dashboard</a>
            </li>
           <li class="bold"><a href="<?php echo base_url();?>nad/students" class="waves-effect waves-cyan"><i class="mdi-social-school"></i> Students</a>
            </li>
            <li class="bold"><a href="<?php echo base_url();?>nad/notifications" class="waves-effect waves-cyan"><i class="mdi-notification-sms"></i> Notifications</a>
            </li>

        </ul>
        <a href="#" data-activates="slide-out" class="sidebar-collapse btn-floating btn-medium waves-effect waves-light hide-on-large-only cyan"><i class="mdi-navigation-menu"></i></a>
        </aside>
      <!-- END LEFT SIDEBAR NAV-->
        <!-- START CONTENT -->
        <section id="content">
        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper">
            <!-- Search for small screen -->
          <div class="container">
            <div class="row">
              <div class="col s12 m12 l12">
                <h5 class="breadcrumbs-title"><?=$page_title;?></h5>
                <ol class="breadcrumbs">
                    <li><a href="<?php echo base_url();?>students">Dashboard</a></li>
                    <li class="active"><?=$page_title;?></li>
                </ol>
              </div>
            </div>
          </div>
        </div>
        <!--breadcrumbs end-->
        