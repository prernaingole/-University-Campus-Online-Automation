<?php
class Ajax_model extends CI_Model {


public function insertData($data,$tblName)
{
        $query = $this->db->insert($tblName, $data);
        return "1";
}

public function loginUser($loginUser)
{
        $condition = array(
                "username" => $loginUser["username"],
                "password" => $loginUser["password"]
        );
        $rows = $this->db->where($condition)->get($loginUser["role"])->num_rows();
        if ($rows > 0) {
                $user = $this->db->where($condition)->get($loginUser["role"])->result();                
                $user = $user[0];
        } else {
                $user = array(
                        "id" => "0"
                );
        }
        return $user;
}
public function getNotifications()
{
        $notifications = $this->db->get("notifications")->result();
        return $notifications;
}
public function getColleges()
{
        $colleges = $this->db->get("colleges")->result();
        return $colleges;
}
public function getAchievements($student_id)
{

        $student_achievements = $this->db->where("student_id",$student_id)->get("student_achievements")->result();
        return $student_achievements;
}

public function getCompanies()
{
        $companies = $this->db->get("companies")->result();
        return $companies;
}

public function getStudentInfo($sid)
	{
		$studentInfo = $this->db->where("id",$sid)->get("students")->result();
		return $studentInfo[0];
        }
        
        public function updateStudent() {
                $sid = $this->session->id;
                $this->db->where("id",$sid)->set($this->input->post())->update("students");
                return true;
        }

}